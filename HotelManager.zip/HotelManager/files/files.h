#ifndef FILES_H
#define FILES_H
#include "models/room.h"
#include <QMessageBox>
#include <QFileDialog>

std::vector<Room> loadRoomsFromTextFile(QWidget* parent);
void saveRoomsToTextFile(QWidget* parent, const std::vector<Room>& rooms);

#endif // FILES_H
