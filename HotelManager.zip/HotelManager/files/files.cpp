#include "files.h"

std::vector<Room> loadRoomsFromTextFile(QWidget* parent) {
    std::vector<Room> rooms;

    // Открываем диалог выбора файла для чтения
    QString filename = QFileDialog::getOpenFileName(
        parent, // Родительский виджет
        "Выберите файл для загрузки", // Заголовок диалога
        "", // Начальная директория (пустая строка означает текущую директорию)
        "Текстовые файлы (*.txt);;Все файлы (*)" // Фильтры файлов
    );

    // Если пользователь отменил выбор файла, возвращаем пустой вектор
    if (filename.isEmpty()) {
        return rooms;
    }

    QFile file(filename);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(parent, "Ошибка", "Не удалось открыть файл: " + filename);
        throw std::runtime_error("Не удалось открыть файл.");
    }

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine();
        if (line.trimmed().isEmpty()) continue;
        QTextStream lineStream(&line);
        Room room;
        try {
            room.deserializeFromText(lineStream);
            rooms.push_back(room);
        } catch (...) {
            // Пропускаем ошибочную строку
            QMessageBox::warning(parent, "Ошибка десериализации", "Ошибка при разборе строки: " + line);
        }
    }
    file.close();
    return rooms;
}

void saveRoomsToTextFile(QWidget* parent, const std::vector<Room>& rooms) {
    // Открываем диалог выбора файла для сохранения
    QString filename = QFileDialog::getSaveFileName(
        parent, // Родительский виджет
        "Выберите файл для сохранения", // Заголовок диалога
        "", // Начальная директория (пустая строка означает текущую директорию)
        "Текстовые файлы (*.txt);;Все файлы (*)" // Фильтры файлов
    );

    // Если пользователь отменил выбор файла, выходим из функции
    if (filename.isEmpty()) {
        return;
    }

    QFile file(filename);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::critical(parent, "Ошибка", "Не удалось открыть файл для записи: " + filename);
        throw std::runtime_error("Не удалось открыть файл для записи.");
    }

    QTextStream out(&file);

    for (const Room& room : rooms) {
        try {
            room.serializeToText(out); // Используем метод serializeToText для записи данных
        } catch (const std::exception& e) {
            file.close(); // Закрываем файл перед выходом
            QMessageBox::warning(parent, "Ошибка сериализации", "Ошибка сериализации комнаты: " + QString(e.what()));
            throw; // Прерываем выполнение и выбрасываем исключение
        }
    }

    file.close();
    QMessageBox::information(parent, "Успех", "Данные успешно сохранены в файл: " + filename);
}
