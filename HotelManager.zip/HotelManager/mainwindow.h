#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QFileDialog>
#include <QMessageBox>
#include <QFile>
#include <iostream>
#include "models/hotel.h"
#include "models/room.h"
#include "algorithms/sort.h"
#include <QTableWidget>
#include <QtCharts/QChart>
#include <QtCharts/QChartView>
#include <QtCharts/QPieSeries>
#include <QBarSeries>
#include <QBarSet>
#include <QValueAxis>
#include <QCategoryAxis>
using namespace QtCharts;

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class ResultsWindow; // Forward declaration

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void updatePaymentCell(int row);

private slots:
    void onCellChanged(int row, int column);
    void onItemChanged(QTableWidgetItem *item);
    void on_loadFile_triggered();
    void onEditModeToggled(bool enabled);
    void on_saveFile_triggered();
    void onHeaderClicked(int logicalIndex);
    void on_exit_triggered();
    
    // New slots for filtering and search
    void on_filterByRoomType_triggered();
    void on_searchAllColumns_triggered();
    
    // New slots for diagrams
    void on_showRoomTypePieChart_triggered();
    void on_showPaymentBarChart_triggered();
    
    // New slots for queries
    void on_showClientsByRoomType_triggered();
    void on_showClientsByStayDuration_triggered();
    void on_showClientsByPayment_triggered();
    void on_showClientsLeavingSoon_triggered();
    void on_showMinMaxStayDuration_triggered();
    void on_showPreBookedRooms_triggered();
    void on_showClientsWithExtraPayment_triggered();

protected:
    void closeEvent(QCloseEvent *event) override;

private:
    Ui::MainWindow *ui;
    QTableWidget* roomTable;
    bool confirmExit();
    void setupTable();
    void populateTable(const std::vector<Room>& rooms);
    void sortTable(int column, Qt::SortOrder order);
    Hotel myHotel;
    
    // Helper methods for new functionality
    void showFilterDialog();
    void showSearchDialog();
    void showDateRangeDialog();
    void showDurationDialog();
    void showPaymentDialog();
    void showDaysDialog();
    void showRoomTypeDialog();
    void showResultsInNewWindow(const std::vector<Room>& rooms, const QString& title);
};
#endif // MAINWINDOW_H
