#ifndef RESULTSWINDOW_H
#define RESULTSWINDOW_H

#include <QMainWindow>
#include <QTableWidget>
#include "models/room.h"

namespace Ui {
class ResultsWindow;
}

class ResultsWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit ResultsWindow(QWidget *parent = nullptr);
    ~ResultsWindow();
    void setResults(const std::vector<Room>& rooms);
    void setTitle(const QString& title);

private:
    Ui::ResultsWindow *ui;
    QTableWidget* resultsTable;
    void setupTable();
    void populateTable(const std::vector<Room>& rooms);
};

#endif // RESULTSWINDOW_H 