#include <iostream>
#include <vector>
#include <random>
#include <ctime>
#include <iomanip> // Для std::setw
#include "hotel.h"
#include "room.h"

void Hotel::addRoom(const Room& room){
    rooms.push_back(room);
}

Room* Hotel::findRoom(int number) {
    for(Room& room : rooms){
        if(room.getNumber() == number){
            return &room;
        }
    }
    return nullptr;
}

std::vector<Room>& Hotel::getRooms() {
    return rooms;
}

void Hotel::editRoom(int number){
    Room* room;
    room = findRoom(number);

    int choice = 0;
    std::cout << "Выберите поле для изменения: " << std::endl;
    std:: cout << "1. Добавить клиента" << std::endl;
    std::cout << "2. Отредактировать поля клиента" << std::endl;
    std:: cout << "3. Удалить клиента" << std::endl;
    std::cout << ">> ";
    std::cin >> choice;

    switch(choice){
        case 1:
        {   room->populateClient();
            break;
        }
        case 2:
        {   room->editClient();
            break;
        }
        case 3:
        {   room->removeClient();
            break;
        }
        default:
        {
            std::cout << "Ошибка ввода";
        }
    }

}


std::string generateRandomDate(int startYear, int endYear) {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> yearDist(startYear, endYear);
    std::uniform_int_distribution<> monthDist(1, 12);
    std::uniform_int_distribution<> dayDist(1, 28); // Чтобы избежать проблем с февралем и другими месяцами

    int year = yearDist(gen);
    int month = monthDist(gen);
    int day = dayDist(gen);

    std::stringstream ss;
    ss << std::setfill('0') << std::setw(2) << day << "."
       << std::setfill('0') << std::setw(2) << month << "."
       << std::setfill('0') << std::setw(4) << year;

    return ss.str();
}

// Вспомогательная функция для генерации случайного имени
std::string generateRandomName() {
    std::vector<std::string> names = {"Иван", "Артём", "Георгий", "Александр", "Глеб", "Мария", "Максим", "Дмитрий", "Анастасия", "Данил"};
    std::vector<std::string> lastNames = {"Павлов", "Анохин", "Литвинов", "Шилов", "Новиков", "Блинов", "Ларионов", "Спиридонов", "Васильев", "Романов"};
    std::vector<std::string> patronymics = {"Алексеевич", "Макаров", "Борисович", "Егоров", "Дмитриевич", "Николаев", "Владимирович", "Захаров"};

    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> nameDist(0, names.size() - 1);
    std::uniform_int_distribution<> lastNameDist(0, lastNames.size() - 1);
    std::uniform_int_distribution<> patronymicsDist(0, patronymics.size() - 1);

    return lastNames[lastNameDist(gen)] + " " + names[nameDist(gen)] + " " + patronymics[patronymicsDist(gen)];
}


void Hotel::loadFile(std::vector<Room> rms){
    rooms = rms;
}


std::vector<Room> Hotel::getClientsStayingLongerThan(int days) const {
    std::vector<Room> result;
    for (const Room& room : rooms) {
        if (room.getCurrClient() != nullptr) {
            int stay = daysBetween(room.getCheckInDate(), room.getCheckOutDate());
            if (stay > days) {
                result.push_back(room);
            }
        }
    }
    return result;
}

std::vector<Room> Hotel::getClientsStayingShorterThan(int days) const {
    std::vector<Room> result;
    for (const Room& room : rooms) {
        if (room.getCurrClient() != nullptr) {
            int stay = daysBetween(room.getCheckInDate(), room.getCheckOutDate());
            if (stay < days) {
                result.push_back(room);
            }
        }
    }
    return result;
}

std::vector<Room> Hotel::getClientsStayingEqual(int days) const {
    std::vector<Room> result;
    for (const Room& room : rooms) {
        if (room.getCurrClient() != nullptr) {
            int stay = daysBetween(room.getCheckInDate(), room.getCheckOutDate());
            if (stay == days) {
                result.push_back(room);
            }
        }
    }
    return result;
}

std::vector<Room> Hotel::getClientsPayingMoreThan(int amount) const {
    std::vector<Room> result;
    for (const Room& room : rooms) {
        if (room.getCurrClient() != nullptr && room.getAmountPaid() > amount) {
            result.push_back(room);
        }
    }
    return result;
}

std::vector<Room> Hotel::getClientsPayingLessThan(int amount) const {
    std::vector<Room> result;
    for (const Room& room : rooms) {
        if (room.getCurrClient() != nullptr && room.getAmountPaid() > amount) {
            result.push_back(room);
        }
    }
    return result;
}

std::vector<Room> Hotel::getClientsLeavingWithinDays(int days) const {
    std::vector<Room> result;

    // Получаем текущую дату с использованием QDate
    QDate currentDate = QDate::currentDate();

    for (const Room& room : rooms) {
        if (room.getCurrClient() != nullptr) {
            // Вычисляем разницу в днях между текущей датой и датой выезда
            int daysUntilDeparture = currentDate.daysTo(room.getCheckOutDate());

            // Учитываем, что дата выезда может быть в прошлом
            if (daysUntilDeparture >= 0 && daysUntilDeparture <= days) {
                result.push_back(room);
            }
        }
    }
    return result;
}


std::vector<std::pair<Room, int>> Hotel::getMaxMinStay(){
    int maxStay = std::numeric_limits<int>::min();
    int minStay = std::numeric_limits<int>::max();
    Room* maxStayRoom = nullptr;
    Room* minStayRoom = nullptr;

    for (Room& room : rooms) {
        if (room.getCurrClient() != nullptr) {
            int stay = daysBetween(room.getCheckInDate(), room.getCheckOutDate());

            if (stay > maxStay) {
                maxStay = stay;
                maxStayRoom = &room;
            }

            if (stay < minStay) {
                minStay = stay;
                minStayRoom = &room;
            }
        }
    }

    std::vector<std::pair<Room, int>> result;

    // Проверяем, были ли найдены комнаты с минимальным и максимальным сроком проживания
    if (minStayRoom != nullptr) {
        result.push_back({*minStayRoom, minStay}); // Добавляем комнату с минимальным сроком
    }
    if (maxStayRoom != nullptr && maxStayRoom != minStayRoom) { // Проверяем, что комната с макс. сроком не равна комнате с мин. сроком
        result.push_back({*maxStayRoom, maxStay}); // Добавляем комнату с максимальным сроком
    }

    return result;
}

std::vector<Room> Hotel::getReservedRoomNumbers() const {
    std::vector<Room> result;
    for (const Room& room : rooms) {
        if (room.getIsReserved()) { // Проверяем, забронирована ли комната
            result.push_back(room);
        }
    }
    return result;
}

std::vector<Room> Hotel::getClientsNeedingToPayExtra() const {
    std::vector<Room> result;
    for (const Room& room : rooms) {
        if (room.getCurrClient() != nullptr) {
            if (room.getCurrClient()->extraSum != 0) {
                result.push_back(room);
            }
        }
    }
    return result;
}

std::vector<Room> Hotel::getClientsInRoomType(RoomType type) const {
    std::vector<Room> result;
    for (const Room& room : rooms) {
        if (room.getType() == type && room.getCurrClient() != nullptr) {
            result.push_back(room);
        }
    }
    return result;
}
