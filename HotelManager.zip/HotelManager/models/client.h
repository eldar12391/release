#ifndef CLIENT_H
#define CLIENT_H
#include <QString>
#include <QDate>
struct Client{
    QString fullName;
    QDate checkInDate;
    QDate checkOutDate;
    int discountAmount;
    int extraSum;

};


#endif // CLIENT_H
