#include "room.h"
#include <limits>
#include <iostream>
#include <fstream>
#include <sstream>
#include <ctime>
#include <iomanip>
#include <QFile>
#include <QTextStream>
#include <QString>
#include <QDebug>
#include <QMessageBox>
#include <QFileDialog>

QString roomTypeToString(RoomType type) {
    switch (type) {
        case RoomType::Standard:   return "Standard";
        case RoomType::Superior:  return "Superlor";
        case RoomType::Deluxe:     return "Deluxe";
        case RoomType::Suite:      return "Suite";
        case RoomType::Apartment:  return "Apartment";
        default:                  return "Unknown";
    }
}

RoomType stringToRoomType(const QString& str) {
    if (str == "Standard")   return RoomType::Standard;
    if (str == "Superlor")  return RoomType::Superior;
    if (str == "Deluxe")     return RoomType::Deluxe;
    if (str == "Suite")      return RoomType::Suite;
    if (str == "Apartment")  return RoomType::Apartment;
    return RoomType::Standard; // Default
}



Room::Room() : number(0), price(0), type(RoomType::Standard), isReserved(false), currClient(nullptr) {}
Room::Room(unsigned int num, int p, RoomType t) : number(num), price(p), type(t), isReserved(false), currClient(nullptr) {}

bool Room::getIsReserved() const {
    return isReserved;
}


void Room::setIsReserved(bool reserved) {
    isReserved = reserved;
}
void Room::setNumber(int num){number = num; }
void Room::setAmountPaid(int num){ price = num; }
int Room::getNumber() const { return number; }
RoomType Room::getType() const { return type; }
int Room::getPrice() const { return price; }
Client* Room::getCurrClient() const { return currClient; }


void Room::removeClient() {
    delete currClient;
    currClient = nullptr;
    isReserved = false; // Комната становится свободной
}

void Room::assignClient(const Client& client) {
    if (currClient != nullptr) {
        delete currClient; // Освобождаем память предыдущего клиента
    }
    currClient = new Client(client); // Создаем нового клиента
    isReserved = true; // Комната становится забронированной
}

void Room::populateClient() {

}

void Room::editClient() {

}

QString Room::getTypeToStr() const{
    RoomType type = getType();
        switch (type) {
            case RoomType::Standard:  return "Standard";
            case RoomType::Superior:  return "Superior";
            case RoomType::Deluxe:    return "Deluxe";
            case RoomType::Suite:     return "Suite";
            case RoomType::Apartment: return "Apartment";
            default:                  return "Неизвестный класс номера";
        }
}

QDate Room::getCheckInDate() const{
    if (currClient) return currClient->checkInDate;
    return QDate(); // Возвращает невалидную дату
}

QDate Room::getCheckOutDate() const{
    if (currClient) return currClient->checkOutDate;
    return QDate();
}

void Room::serializeToText(QTextStream& out) const {
    out << number << "," << price << "," << getTypeToStr() << ",";
    out << (isReserved ? "Reserved" : "NotReserved") << ",";
    if (currClient) {
        out << "true," << currClient->fullName << ",";
        out << currClient->checkInDate.toString("yyyy-MM-dd") << ",";
        out << currClient->checkOutDate.toString("yyyy-MM-dd") << ",";
        out << currClient->discountAmount << "," << currClient->extraSum;
    } else {
        out << "false,,,,0,0";
    }
    out << "\n";
}

void Room::deserializeFromText(QTextStream& is) {
    QString line = is.readLine();
    if (line.isEmpty()) return;
    QStringList tokens = line.split(',', Qt::KeepEmptyParts);
    if (currClient) {
        delete currClient;
        currClient = nullptr;
    }
    if (tokens.size() >= 6) {
        bool ok;
        number = tokens[0].toUInt(&ok);
        price = tokens[1].toInt(&ok);
        setTypeFromStr(tokens[2]);
        isReserved = (tokens[3].compare("Reserved", Qt::CaseInsensitive) == 0);
        bool hasClient = (tokens[4].compare("true", Qt::CaseInsensitive) == 0);
        if (hasClient && tokens.size() >= 10) {
            currClient = new Client();
            currClient->fullName = tokens[5];
            currClient->checkInDate = QDate::fromString(tokens[6], "yyyy-MM-dd");
            currClient->checkOutDate = QDate::fromString(tokens[7], "yyyy-MM-dd");
            currClient->discountAmount = tokens[8].toInt(&ok);
            currClient->extraSum = tokens[9].toInt(&ok);
        } else {
            currClient = nullptr;
        }
    } else {
        qDebug() << "Недостаточно данных для комнаты: " << line;
    }
}


int daysBetween(const QDate& date1, const QDate& date2) { // const QDate&
    // Простая и надежная реализация с использованием QDate::daysTo()
    return date1.daysTo(date2);
}

int Room::getAmountPaid() const{
    if (!currClient) return 0;
    int amount = daysBetween(getCheckInDate(), getCheckOutDate()) * price;
    return amount;
}


void Room::setTypeFromStr(const QString& typeStr) {
    if (typeStr.compare("Standart", Qt::CaseInsensitive) == 0 ||
        typeStr.compare("Standard", Qt::CaseInsensitive) == 0) {
        type = RoomType::Standard;
    }
    else if (typeStr.compare("Superlor", Qt::CaseInsensitive) == 0 ||
             typeStr.compare("Superlor", Qt::CaseInsensitive) == 0) {
        type = RoomType::Superior;
    }
    else if (typeStr.compare("Deluxe", Qt::CaseInsensitive) == 0 ||
             typeStr.compare("Deluxe", Qt::CaseInsensitive) == 0) {
        type = RoomType::Deluxe;
    }
    else if (typeStr.compare("Suite", Qt::CaseInsensitive) == 0 ||
             typeStr.compare("Suite", Qt::CaseInsensitive) == 0) {
        type = RoomType::Suite;
    }
    else if (typeStr.compare("Apartment", Qt::CaseInsensitive) == 0 ||
             typeStr.compare("Apartment", Qt::CaseInsensitive) == 0) {
        type = RoomType::Apartment;
    }
    else {
        // Значение по умолчанию или можно бросить исключение
        type = RoomType::Standard;
        // throw std::invalid_argument("Неизвестный тип комнаты: " + typeStr.toStdString());
    }
}


void Room::setCheckInDate(const QDate& date) {
    if (currClient) {
        currClient->checkInDate = date;
    }
}

void Room::setCheckOutDate(const QDate& date) {
    if (currClient) {
        currClient->checkOutDate = date;
    }
}

Room::~Room() {
    delete currClient;
}

Room::Room(const Room& other)
    : number(other.number), price(other.price), type(other.type), isReserved(other.isReserved)
{
    if (other.currClient)
        currClient = new Client(*other.currClient);
    else
        currClient = nullptr;
}

Room& Room::operator=(const Room& other) {
    if (this == &other) return *this;
    number = other.number;
    price = other.price;
    type = other.type;
    isReserved = other.isReserved;
    if (currClient) delete currClient;
    if (other.currClient)
        currClient = new Client(*other.currClient);
    else
        currClient = nullptr;
    return *this;
}
