#ifndef ROOM_H
#define ROOM_H
#include <QString>
#include <QTextStream>
#include "client.h"

enum class RoomType { Standard, Superior, Deluxe, Suite, Apartment };

int daysBetween(const QDate& date1, const QDate& date2);

class Room
{
private:
    unsigned int number;
    int price;
    RoomType type;
    bool isReserved; // Заменяем RoomStatus на bool isReserved
    Client* currClient;

public:
    Room(unsigned int num, int p, RoomType t);
    Room();
    Room(const Room& other);
    Room& operator=(const Room& other);
    ~Room();
    void setNumber(int num);
    void setAmountPaid(int num);
    void setTypeFromStr(const QString& typeStr);
    void setCheckInDate(const QDate& date);
    void setCheckOutDate(const QDate& date);


    int getNumber() const;
    RoomType getType() const;
    bool getIsReserved() const; // Новый метод для получения статуса бронирования
    int getPrice() const;
    Client* getCurrClient() const;
    QDate getCheckInDate() const;
    QDate getCheckOutDate() const;
    int getAmountPaid() const;
    void addClient();
    void setIsReserved(bool reserved); // Новый метод для установки статуса бронирования
    void assignClient(const Client& client);
    void editClient();
    void removeClient();
    void populateClient();
    void serializeToText(QTextStream& os) const;
    void deserializeFromText(QTextStream& is);
    QString getTypeToStr() const;
    QString getIsReservedToStr() const; // Новый метод для получения строкового представления статуса бронирования
};

#endif // ROOM_H
