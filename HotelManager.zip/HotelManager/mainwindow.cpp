#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "models/room.h"
#include <QFileDialog>
#include <QMessageBox>
#include <QFile>
#include <iostream>
#include "files/files.h"
#include "algorithms/sort.h"
#include <QCloseEvent>
#include <QDateEdit>
#include <QCheckBox>
#include <QComboBox>
#include <QInputDialog>
#include <QDialog>
#include <QVBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QSpinBox>
#include <QDateEdit>
#include <QtCharts/QChartView>
#include <QtCharts/QPieSeries>
#include <QtCharts/QChart>
#include <QtCharts/QPieSlice>
#include <QBarSeries>
#include <QBarSet>
#include <QValueAxis>
#include <QCategoryAxis>
#include "resultswindow.h"
#include <QDebug>
using namespace QtCharts;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    roomTable = ui->roomTables;
    setupTable();
    connect(roomTable->horizontalHeader(), &QHeaderView::sectionClicked, this, &MainWindow::onHeaderClicked);
    connect(ui->editMode, &QAction::toggled, this, &MainWindow::onEditModeToggled);

    connect(roomTable, &QTableWidget::cellChanged, this, &MainWindow::onCellChanged);
    connect(roomTable, &QTableWidget::itemChanged, this, &MainWindow::onItemChanged);

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::setupTable() {
    // Устанавливаем количество столбцов
    roomTable->setColumnCount(9);

    // Устанавливаем заголовки столбцов
    QStringList headers = {
        "№ в гостинице", "Клиент", "Дата заселения", "Дата выезда",
        "Класс номера", "Оплата", "Скидки", "Бронь", "Доплаты"
    };
    roomTable->setHorizontalHeaderLabels(headers);

    // Настраиваем поведение столбцов
    roomTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch); // Растягиваем все столбцы
    roomTable->verticalHeader()->setVisible(false); // Отключаем номера строк

    // Настраиваем политику изменения размера для таблицы
    roomTable->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);

    // Настраиваем ширину столбцов (опционально, если нужно задать начальные пропорции)
    roomTable->setColumnWidth(0, 100); // № в гостинице
    roomTable->setColumnWidth(1, 200); // Клиент
    roomTable->setColumnWidth(2, 120); // Дата заселения
    roomTable->setColumnWidth(3, 120); // Дата выезда
    roomTable->setColumnWidth(4, 120); // Класс номера
    roomTable->setColumnWidth(5, 80);  // Оплата
    roomTable->setColumnWidth(6, 80);  // Скидки
    roomTable->setColumnWidth(7, 80);  // Бронь
    roomTable->setColumnWidth(8, 80);  // Доплаты
}

void MainWindow::on_loadFile_triggered() {
    try {
        // Вызываем функцию загрузки данных из файла
        std::vector<Room> rooms = loadRoomsFromTextFile(this);
        myHotel.loadFile(rooms);
        populateTable(myHotel.getRooms());
        // Выводим сообщение об успешной загрузке
        QMessageBox::information(this, "Успех", "Данные успешно загружены. Загружено комнат: " + QString::number(rooms.size()));

        // Здесь можно обновить интерфейс или сохранить загруженные данные в классе MainWindow
        // Например:
        // this->rooms = rooms; // Если у вас есть переменная-член rooms в MainWindow
    } catch (const std::exception& e) {
        // Обработка ошибок
        QMessageBox::critical(this, "Ошибка", "Не удалось загрузить данные: " + QString(e.what()));
    }
}

void MainWindow::on_saveFile_triggered() {
    try {
        // Проверяем, есть ли данные для сохранения
        if (myHotel.getRooms().empty()) {
            QMessageBox::warning(this, "Предупреждение", "Нет данных для сохранения.");
            return;
        }

        // Открываем диалог выбора файла для сохранения
        QString filename = QFileDialog::getSaveFileName(
            this, // Родительский виджет
            "Выберите файл для сохранения", // Заголовок диалога
            "", // Начальная директория (пустая строка означает текущую директорию)
            "Текстовые файлы (*.txt);;Все файлы (*)" // Фильтры файлов
        );

        // Если пользователь отменил выбор файла, выходим из функции
        if (filename.isEmpty()) {
            return;
        }

        // Проверяем расширение файла
        if (!filename.endsWith(".txt", Qt::CaseInsensitive)) {
            QMessageBox::critical(this, "Ошибка", "Файл должен иметь расширение .txt.");
            return;
        }

        // Проверяем, существует ли файл, и запрашиваем подтверждение перезаписи
        if (QFile::exists(filename)) {
            QMessageBox::StandardButton reply = QMessageBox::question(
                this, "Подтверждение", "Файл уже существует. Перезаписать?",
                QMessageBox::Yes | QMessageBox::No
            );

            if (reply == QMessageBox::No) {
                return; // Отмена сохранения
            }
        }

        // Открываем файл для записи
        QFile file(filename);
        if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
            QMessageBox::critical(this, "Ошибка", "Не удалось открыть файл для записи: " + filename);
            throw std::runtime_error("Не удалось открыть файл для записи.");
        }

        // Записываем данные в файл
        QTextStream out(&file);
        for (const Room& room : myHotel.getRooms()) {
            try {
                room.serializeToText(out); // Используем метод serializeToText для записи данных
            } catch (const std::exception& e) {
                file.close(); // Закрываем файл перед выходом
                QMessageBox::warning(this, "Ошибка сериализации", "Ошибка сериализации комнаты: " + QString(e.what()));
                throw; // Прерываем выполнение и выбрасываем исключение
            }
        }

        file.close(); // Закрываем файл после записи

        // Выводим сообщение об успешном сохранении
        QMessageBox::information(this, "Успех", "Данные успешно сохранены в файл: " + filename);
    } catch (const std::exception& e) {
        QMessageBox::critical(this, "Ошибка", "Не удалось сохранить данные: " + QString(e.what()));
    }
}

void MainWindow::populateTable(const std::vector<Room>& rooms) {
    // Очищаем таблицу перед заполнением
    roomTable->setRowCount(0);

    // Заполняем таблицу данными
    for (const Room& room : rooms) {
        int row = roomTable->rowCount();
        roomTable->insertRow(row);

        // № в гостинице
        roomTable->setItem(row, 0, new QTableWidgetItem(QString::number(room.getNumber())));

        // Клиент
        Client* client = room.getCurrClient();
        QString clientName = client ? client->fullName : "Нет клиента";
        roomTable->setItem(row, 1, new QTableWidgetItem(clientName));

        // Дата заселения
        QDateEdit* checkInDateEdit = new QDateEdit(client ? client->checkInDate : QDate::currentDate());
        checkInDateEdit->setCalendarPopup(true);
        checkInDateEdit->setDisplayFormat("dd.MM.yyyy");
        checkInDateEdit->setEnabled(ui->editMode->isChecked());
        connect(checkInDateEdit, &QDateEdit::dateChanged, this, [this, row](const QDate& date) {
            if (ui->editMode->isChecked()) {
                myHotel.getRooms()[row].setCheckInDate(date);
                // Пересчёт оплаты
                updatePaymentCell(row);
            }
        });
        roomTable->setCellWidget(row, 2, checkInDateEdit);

        // Дата выезда
        QDateEdit* checkOutDateEdit = new QDateEdit(client ? client->checkOutDate : QDate::currentDate());
        checkOutDateEdit->setCalendarPopup(true);
        checkOutDateEdit->setDisplayFormat("dd.MM.yyyy");
        checkOutDateEdit->setEnabled(ui->editMode->isChecked());
        connect(checkOutDateEdit, &QDateEdit::dateChanged, this, [this, row](const QDate& date) {
            if (ui->editMode->isChecked()) {
                myHotel.getRooms()[row].setCheckOutDate(date);
                // Пересчёт оплаты
                updatePaymentCell(row);
            }
        });
        roomTable->setCellWidget(row, 3, checkOutDateEdit);

        // Класс номера
        QComboBox* typeCombo = new QComboBox();
        typeCombo->addItems({"Standard", "Superior", "Deluxe", "Suite", "Apartment"});
        typeCombo->setCurrentText(room.getTypeToStr());
        typeCombo->setEnabled(ui->editMode->isChecked());
        connect(typeCombo, QOverload<int>::of(&QComboBox::currentIndexChanged),
                this, [this, row](int index) {
            if (ui->editMode->isChecked()) {
                Room& room = myHotel.getRooms()[row];
                QString typeStr = static_cast<QComboBox*>(sender())->currentText();
                room.setTypeFromStr(typeStr);
                // Устанавливаем цену в зависимости от класса
                int price = 0;
                if (typeStr == "Standard") price = 2000;
                else if (typeStr == "Superior") price = 3000;
                else if (typeStr == "Deluxe") price = 4000;
                else if (typeStr == "Suite") price = 6000;
                else if (typeStr == "Apartment") price = 8000;
                room.setAmountPaid(price); // setAmountPaid меняет price
                updatePaymentCell(row);
            }
        });
        roomTable->setCellWidget(row, 4, typeCombo);

        // Оплата (только для чтения)
        QTableWidgetItem* paymentItem = new QTableWidgetItem();
        paymentItem->setFlags(paymentItem->flags() & ~Qt::ItemIsEditable); // Только для чтения
        if (client) {
            int discountAmount = std::max(0, std::min(client->discountAmount, 100));
            QDate in = room.getCheckInDate();
            QDate out = room.getCheckOutDate();
            int days = in.isValid() && out.isValid() ? in.daysTo(out) : 0;
            if (days < 0) days = 0;
            int fullAmount = days * room.getPrice();
            int discountedAmount = fullAmount * (100 - discountAmount) / 100;
            QString paymentText = QString::number(discountedAmount) + " (" + QString::number(fullAmount) + ")";
            paymentItem->setText(paymentText);
        } else {
            paymentItem->setText("—");
        }
        roomTable->setItem(row, 5, paymentItem);

        // Скидки
        QSpinBox* discountSpin = new QSpinBox();
        discountSpin->setRange(0, 100);
        discountSpin->setSingleStep(1);
        discountSpin->setValue(client ? std::max(0, std::min(client->discountAmount, 100)) : 0);
        discountSpin->setEnabled(ui->editMode->isChecked());
        connect(discountSpin, QOverload<int>::of(&QSpinBox::valueChanged), this, [this, row](int val) {
            if (ui->editMode->isChecked()) {
                Room& room = myHotel.getRooms()[row];
                if (room.getCurrClient()) {
                    room.getCurrClient()->discountAmount = val;
                    updatePaymentCell(row);
                }
            }
        });
        roomTable->setCellWidget(row, 6, discountSpin);

        // Бронь
        QCheckBox* checkBox = new QCheckBox();
        checkBox->setChecked(room.getIsReserved());
        checkBox->setEnabled(ui->editMode->isChecked());
        connect(checkBox, &QCheckBox::stateChanged, this, [this, row](int state) {
            if (ui->editMode->isChecked()) {
                myHotel.getRooms()[row].setIsReserved(state == Qt::Checked);
            }
        });
        roomTable->setCellWidget(row, 7, checkBox);

        // Доплаты
        int extraSum = client ? client->extraSum : 0;
        roomTable->setItem(row, 8, new QTableWidgetItem(QString::number(extraSum)));
    }
    onEditModeToggled(ui->editMode->isChecked());
}

void MainWindow::sortTable(int column, Qt::SortOrder order) {
    SortOrder sortOrder = (order == Qt::AscendingOrder) ? SortOrder::Ascending : SortOrder::Descending;
    std::vector<Room>& rooms = myHotel.getRooms(); // Сортируем оригинал!
    switch (column) {
        case 0: sortByRoomNumber(rooms, sortOrder); break;
        case 1: sortByClientFullName(rooms, sortOrder); break;
        case 2: sortByCheckInDate(rooms, sortOrder); break;
        case 3: sortByCheckOutDate(rooms, sortOrder); break;
        case 4: sortByRoomType(rooms, sortOrder); break;
        case 7: sortByRoomStatus(rooms, sortOrder); break;
        case 5: // Цена
            // Добавьте функцию сортировки по цене, если нужно
            break;
        case 6: // Скидка
            // Добавьте функцию сортировки по скидке, если нужно
            break;
        case 8: // Доплата
            // Добавьте функцию сортировки по доплате, если нужно
            break;
        default:
            break;
    }
    populateTable(rooms);
}

void MainWindow::onHeaderClicked(int logicalIndex) {
    // Получаем текущий порядок сортировки
    QList<int> sortableColumns = {0, 1, 2, 3, 4, 7}; // Номера столбцов, которые можно сортировать

        // Если столбец не поддерживает сортировку, выходим
    if (!sortableColumns.contains(logicalIndex)) {
        qDebug() << "Столбец" << logicalIndex << "не поддерживает сортировку.";
        return;
    }
    Qt::SortOrder order = roomTable->horizontalHeader()->sortIndicatorOrder();

    // Меняем порядок сортировки на противоположный

    // Выполняем сортировку
    sortTable(logicalIndex, order);

    // Устанавливаем новый порядок сортировки в заголовке
    roomTable->horizontalHeader()->setSortIndicator(logicalIndex, order);
}

bool MainWindow::confirmExit() {
    // Создаем диалог подтверждения
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Подтверждение выхода", "Вы уверены, что хотите выйти?",
                                  QMessageBox::Yes | QMessageBox::No);

    // Возвращаем true, если пользователь подтвердил выход
    return (reply == QMessageBox::Yes);
}

void MainWindow::on_exit_triggered() {
    this->close();
}

void MainWindow::closeEvent(QCloseEvent *event) {
    if (confirmExit()) {
        event->accept(); // Закрываем окно
    } else {
        event->ignore(); // Отменяем закрытие окна
    }
}

void MainWindow::onCellChanged(int row, int column)
{
    if (!ui->editMode->isChecked()) return; // Игнорируем в режиме просмотра

    QTableWidgetItem* item = roomTable->item(row, column);
    if (!item) return;

    Room& room = myHotel.getRooms()[row]; // Получаем комнату из вашего вектора

    switch (column) {
        case 0: // № в гостинице
            room.setNumber(item->text().toInt());
            break;
        case 1: // Клиент
            if (room.getCurrClient()) {
                QString newName = item->text();
                if (newName.trimmed().isEmpty()) {
                    room.removeClient();
                    // Обновить строку в таблице: все клиентские поля должны стать пустыми/дефолтными
                    roomTable->item(row, 1)->setText("Нет клиента");
                    if (QDateEdit* de = qobject_cast<QDateEdit*>(roomTable->cellWidget(row, 2))) de->setDate(QDate::currentDate());
                    if (QDateEdit* de = qobject_cast<QDateEdit*>(roomTable->cellWidget(row, 3))) de->setDate(QDate::currentDate());
                    if (QSpinBox* sb = qobject_cast<QSpinBox*>(roomTable->cellWidget(row, 6))) sb->setValue(0);
                    if (QCheckBox* cb = qobject_cast<QCheckBox*>(roomTable->cellWidget(row, 7))) cb->setChecked(false);
                    roomTable->item(row, 5)->setText("—");
                    roomTable->item(row, 8)->setText("0");
                } else {
                    room.getCurrClient()->fullName = newName;
                }
            }
            break;
        case 4: // Класс номера
            break;
        // case 5: // Оплата
        //     // УБРАНО! Не редактируем и не сохраняем оплату вручную
        //     break;
        case 8: // Доплаты
            if (room.getCurrClient()) {
                room.getCurrClient()->extraSum = item->text().toInt();
            }
            break;
    }
}

void MainWindow::onItemChanged(QTableWidgetItem *item)
{
    if (!ui->editMode->isChecked()) return;

    int row = item->row();
    int column = item->column();
    Room& room = myHotel.getRooms()[row];

    // Обработка для QDateEdit (колонки 2 и 3)
    if (column == 2 || column == 3) {
        QDateEdit* dateEdit = qobject_cast<QDateEdit*>(roomTable->cellWidget(row, column));
        if (dateEdit) {
            QDate date = dateEdit->date();
            if (column == 2) {
                room.setCheckInDate(date);
            } else {
                room.setCheckOutDate(date);
            }
        }
    }
    // Обработка для QCheckBox (колонка 7)
    else if (column == 7) {
        QCheckBox* checkBox = qobject_cast<QCheckBox*>(roomTable->cellWidget(row, column));
        if (checkBox) {
            room.setIsReserved(checkBox->isChecked());
        }
    }
}

void MainWindow::onEditModeToggled(bool enabled)
{
    for (int row = 0; row <roomTable->rowCount(); ++row) {
        // Колонка 2: QDateEdit (Дата заселения)
        if (QDateEdit* de = qobject_cast<QDateEdit*>(roomTable->cellWidget(row, 2))) {
            de->setEnabled(enabled);
        }

        // Колонка 3: QDateEdit (Дата выезда)
        if (QDateEdit* de = qobject_cast<QDateEdit*>(roomTable->cellWidget(row, 3))) {
            de->setEnabled(enabled);
        }

        // Колонка 7: QCheckBox (Бронь)
        if (QCheckBox* cb = qobject_cast<QCheckBox*>(roomTable->cellWidget(row, 7))) {
            cb->setEnabled(enabled);
        }

        // Остальные колонки (обычные QTableWidgetItem)
        for (int col : {0, 1, 4, 5, 8}) {
            if (QTableWidgetItem* item = roomTable->item(row, col)) {
                item->setFlags(enabled
                    ? item->flags() | Qt::ItemIsEditable
                    : item->flags() & ~Qt::ItemIsEditable);
            }
            if (QComboBox* cb = qobject_cast<QComboBox*>(roomTable->cellWidget(row, 4))) {
                        cb->setEnabled(enabled);
                    }
        }

        // Колонка 6: QSpinBox (Скидки)
        if (QSpinBox* sb = qobject_cast<QSpinBox*>(roomTable->cellWidget(row, 6))) {
            sb->setEnabled(enabled);
        }
    }

    // Визуальная индикация режима
    roomTable->setStyleSheet(enabled
        ? ""
        : "QTableWidget { color: #888; } QTableWidget::item { border: 1px solid #ddd; }");
}

// Filter and Search Implementation
void MainWindow::on_filterByRoomType_triggered()
{
    showRoomTypeDialog();
}

void MainWindow::on_searchAllColumns_triggered()
{
    showSearchDialog();
}

void MainWindow::showResultsInNewWindow(const std::vector<Room>& rooms, const QString& title)
{
    ResultsWindow* resultsWindow = new ResultsWindow(this);
    resultsWindow->setResults(rooms);
    resultsWindow->setTitle(title);
    resultsWindow->show();
}

void MainWindow::showRoomTypeDialog()
{
    QDialog dialog(this);
    dialog.setWindowTitle("Фильтр по типу номера");
    QVBoxLayout layout(&dialog);
    QComboBox roomTypeCombo;
    roomTypeCombo.addItems({"Standard", "Superior", "Deluxe", "Suite", "Apartment"});
    QPushButton applyButton("Применить");
    QPushButton cancelButton("Отмена");
    layout.addWidget(new QLabel("Выберите тип номера:"));
    layout.addWidget(&roomTypeCombo);
    layout.addWidget(&applyButton);
    layout.addWidget(&cancelButton);
    connect(&applyButton, &QPushButton::clicked, [&]() {
        QString selectedType = roomTypeCombo.currentText();
        std::vector<Room> filteredRooms;
        int filteredCount = 0;
        int totalCount = myHotel.getRooms().size();
        for (const Room& room : myHotel.getRooms()) {
            if (room.getTypeToStr() == selectedType) {
                filteredRooms.push_back(room);
                filteredCount++;
            }
        }
        showResultsInNewWindow(filteredRooms, "Результаты фильтрации по типу номера: " + selectedType);
        // Круговая диаграмма: доля выбранных комнат
        QPieSeries* series = new QPieSeries();
        series->append("Выбранные (" + QString::number(filteredCount) + ")", filteredCount);
        series->append("Остальные (" + QString::number(totalCount - filteredCount) + ")", totalCount - filteredCount);
        for (auto slice : series->slices()) {
            slice->setLabelVisible(true);
            QObject::connect(slice, &QPieSlice::hovered, [slice](bool state) {
                slice->setExploded(state);
                slice->setLabelFont(QFont("Arial", state ? 14 : 10, QFont::Bold));
            });
        }
        QChart* chart = new QChart();
        chart->addSeries(series);
        chart->setTitle("Доля выбранных комнат от общего числа");
        chart->legend()->setVisible(true);
        chart->legend()->setAlignment(Qt::AlignRight);
        chart->setAnimationOptions(QChart::AllAnimations);
        QChartView* chartView = new QChartView(chart);
        chartView->setRenderHint(QPainter::Antialiasing);
        QDialog pieDialog(this);
        pieDialog.setWindowTitle("Доля выбранных комнат");
        QVBoxLayout pieLayout(&pieDialog);
        pieLayout.addWidget(chartView);
        pieDialog.resize(600, 400);
        pieDialog.exec();
        dialog.accept();
    });
    connect(&cancelButton, &QPushButton::clicked, &dialog, &QDialog::reject);
    dialog.exec();
}

void MainWindow::showSearchDialog()
{
    bool ok;
    QString searchText = QInputDialog::getText(this, "Поиск", 
        "Введите текст для поиска:", QLineEdit::Normal, "", &ok);
    
    if (ok && !searchText.isEmpty()) {
        std::vector<Room> searchResults;
        for (const Room& room : myHotel.getRooms()) {
            bool found = false;
            if (QString::number(room.getNumber()).contains(searchText, Qt::CaseInsensitive)) {
                found = true;
            }
            if (room.getCurrClient() && 
                room.getCurrClient()->fullName.contains(searchText, Qt::CaseInsensitive)) {
                found = true;
            }
            if (room.getTypeToStr().contains(searchText, Qt::CaseInsensitive)) {
                found = true;
            }
            if (QString::number(room.getAmountPaid()).contains(searchText, Qt::CaseInsensitive)) {
                found = true;
            }
            
            if (found) {
                searchResults.push_back(room);
            }
        }
        showResultsInNewWindow(searchResults, "Результаты поиска: " + searchText);
    }
}

// Diagrams Implementation
void MainWindow::on_showRoomTypePieChart_triggered()
{
    QPieSeries *series = new QPieSeries();
    QMap<QString, int> roomTypeCount;
    for (const Room& room : myHotel.getRooms()) {
        if (room.getCurrClient()) {
            roomTypeCount[room.getTypeToStr()]++;
        }
    }
    for (auto it = roomTypeCount.begin(); it != roomTypeCount.end(); ++it) {
        QPieSlice* slice = series->append(it.key(), it.value());
        slice->setLabelVisible(true);
    }
    // Красивое оформление: отделение сегмента при наведении
    for (auto slice : series->slices()) {
        QObject::connect(slice, &QPieSlice::hovered, [slice](bool state) {
            slice->setExploded(state);
            slice->setLabelFont(QFont("Arial", state ? 14 : 10, QFont::Bold));
        });
    }
    QChart *chart = new QChart();
    chart->addSeries(series);
    chart->setTitle("Распределение занятых номеров по типам");
    chart->legend()->setVisible(true);
    chart->legend()->setAlignment(Qt::AlignRight);
    chart->setAnimationOptions(QChart::AllAnimations);
    QChartView *chartView = new QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);
    QDialog dialog(this);
    dialog.setWindowTitle("Круговая диаграмма");
    QVBoxLayout layout(&dialog);
    layout.addWidget(chartView);
    dialog.resize(800, 600);
    dialog.exec();
}

void MainWindow::on_showPaymentBarChart_triggered()
{
    showDateRangeDialog();
}

void MainWindow::showDateRangeDialog()
{
    QDialog dialog(this);
    dialog.setWindowTitle("Выбор периода");
    QVBoxLayout layout(&dialog);
    QDateEdit startDateEdit;
    QDateEdit endDateEdit;
    QPushButton showButton("Показать");
    startDateEdit.setCalendarPopup(true);
    endDateEdit.setCalendarPopup(true);
    startDateEdit.setDate(QDate::currentDate().addDays(-30));
    endDateEdit.setDate(QDate::currentDate());
    layout.addWidget(new QLabel("Начальная дата:"));
    layout.addWidget(&startDateEdit);
    layout.addWidget(new QLabel("Конечная дата:"));
    layout.addWidget(&endDateEdit);
    layout.addWidget(&showButton);
    connect(&showButton, &QPushButton::clicked, [&]() {
        QBarSeries *series = new QBarSeries();
        QMap<QString, int> paymentByType;
        for (const Room& room : myHotel.getRooms()) {
            if (room.getCurrClient()) {
                QDate checkInDate = room.getCurrClient()->checkInDate;
                if (checkInDate >= startDateEdit.date() && checkInDate <= endDateEdit.date()) {
                    paymentByType[room.getTypeToStr()] += room.getAmountPaid();
                }
            }
        }
        if (paymentByType.isEmpty()) {
            QMessageBox::information(this, "Информация", "Нет данных за выбранный период");
            return;
        }
        QStringList colorList = {"#3498db", "#e74c3c", "#2ecc71", "#f1c40f", "#9b59b6", "#e67e22", "#1abc9c"};
        QStringList categories;
        int maxPayment = 0;
        int colorIdx = 0;
        for (auto it = paymentByType.begin(); it != paymentByType.end(); ++it) {
            QBarSet* set = new QBarSet(it.key());
            *set << it.value();
            set->setColor(QColor(colorList[colorIdx % colorList.size()]));
            series->append(set);
            categories << it.key();
            maxPayment = qMax(maxPayment, it.value());
            colorIdx++;
        }
        QChart *chart = new QChart();
        chart->addSeries(series);
        chart->setTitle("Суммарная оплата по типам номеров за период");
        chart->setAnimationOptions(QChart::AllAnimations);
        QCategoryAxis *axisX = new QCategoryAxis();
        for (int i = 0; i < categories.size(); ++i) {
            axisX->append(categories[i], i);
        }
        chart->addAxis(axisX, Qt::AlignBottom);
        series->attachAxis(axisX);
        QValueAxis *axisY = new QValueAxis();
        axisY->setRange(0, maxPayment * 1.1);
        axisY->setTitleText("Сумма оплаты");
        chart->addAxis(axisY, Qt::AlignLeft);
        series->attachAxis(axisY);
        chart->legend()->setVisible(true);
        chart->legend()->setAlignment(Qt::AlignBottom);
        QChartView *chartView = new QChartView(chart);
        chartView->setRenderHint(QPainter::Antialiasing);
        QDialog chartDialog(this);
        chartDialog.setWindowTitle("Столбчатая диаграмма");
        QVBoxLayout chartLayout(&chartDialog);
        chartLayout.addWidget(chartView);
        chartDialog.resize(900, 600);
        chartDialog.exec();
        dialog.accept();
    });
    dialog.exec();
}

// Queries Implementation
void MainWindow::on_showClientsByRoomType_triggered()
{
    showRoomTypeDialog();
}

void MainWindow::on_showClientsByStayDuration_triggered()
{
    showDurationDialog();
}

void MainWindow::on_showClientsByPayment_triggered()
{
    showPaymentDialog();
}

void MainWindow::on_showClientsLeavingSoon_triggered()
{
    showDaysDialog();
}

void MainWindow::showDurationDialog()
{
    QDialog dialog(this);
    dialog.setWindowTitle("Выбор длительности проживания");
    
    QVBoxLayout layout(&dialog);
    QSpinBox daysSpinBox;
    QComboBox comparisonCombo;
    comparisonCombo.addItems({"Меньше", "Равно", "Больше"});
    QPushButton showButton("Показать");
    
    layout.addWidget(new QLabel("Количество дней:"));
    layout.addWidget(&daysSpinBox);
    layout.addWidget(new QLabel("Сравнение:"));
    layout.addWidget(&comparisonCombo);
    layout.addWidget(&showButton);
    
    connect(&showButton, &QPushButton::clicked, [&]() {
        std::vector<Room> filteredRooms;
        int days = daysSpinBox.value();
        QString comparison = comparisonCombo.currentText();
        
        for (const Room& room : myHotel.getRooms()) {
            if (room.getCurrClient()) {
                int stayDays = room.getCurrClient()->checkInDate.daysTo(
                    room.getCurrClient()->checkOutDate);
                
                if ((comparison == "Меньше" && stayDays < days) ||
                    (comparison == "Равно" && stayDays == days) ||
                    (comparison == "Больше" && stayDays > days)) {
                    filteredRooms.push_back(room);
                }
            }
        }
        
        showResultsInNewWindow(filteredRooms, "Результаты поиска по длительности проживания");
        dialog.accept();
    });
    
    dialog.exec();
}

void MainWindow::showPaymentDialog()
{
    QDialog dialog(this);
    dialog.setWindowTitle("Выбор суммы оплаты");
    
    QVBoxLayout layout(&dialog);
    QSpinBox paymentSpinBox;
    paymentSpinBox.setRange(0, 1000000); // Устанавливаем диапазон от 0 до 1 000 000
    paymentSpinBox.setSingleStep(100); // Шаг изменения 100 рублей
    QComboBox comparisonCombo;
    comparisonCombo.addItems({"Меньше", "Равно", "Больше"});
    QPushButton showButton("Показать");
    
    layout.addWidget(new QLabel("Сумма оплаты:"));
    layout.addWidget(&paymentSpinBox);
    layout.addWidget(new QLabel("Сравнение:"));
    layout.addWidget(&comparisonCombo);
    layout.addWidget(&showButton);
    
    connect(&showButton, &QPushButton::clicked, [&]() {
        std::vector<Room> filteredRooms;
        int payment = paymentSpinBox.value();
        QString comparison = comparisonCombo.currentText();
        
        for (const Room& room : myHotel.getRooms()) {
            if ((comparison == "Меньше" && room.getAmountPaid() < payment) ||
                (comparison == "Равно" && room.getAmountPaid() == payment) ||
                (comparison == "Больше" && room.getAmountPaid() > payment)) {
                filteredRooms.push_back(room);
            }
        }
        
        showResultsInNewWindow(filteredRooms, "Результаты поиска по сумме оплаты");
        dialog.accept();
    });
    
    dialog.exec();
}

void MainWindow::showDaysDialog()
{
    QDialog dialog(this);
    dialog.setWindowTitle("Выбор количества дней");
    
    QVBoxLayout layout(&dialog);
    QSpinBox daysSpinBox;
    QPushButton showButton("Показать");
    
    layout.addWidget(new QLabel("Количество дней до выезда:"));
    layout.addWidget(&daysSpinBox);
    layout.addWidget(&showButton);
    
    connect(&showButton, &QPushButton::clicked, [&]() {
        std::vector<Room> filteredRooms;
        int days = daysSpinBox.value();
        QDate currentDate = QDate::currentDate();
        
        for (const Room& room : myHotel.getRooms()) {
            if (room.getCurrClient()) {
                int daysUntilCheckout = currentDate.daysTo(room.getCurrClient()->checkOutDate);
                if (daysUntilCheckout <= days && daysUntilCheckout >= 0) {
                    filteredRooms.push_back(room);
                }
            }
        }
        
        showResultsInNewWindow(filteredRooms, "Клиенты, выезжающие в течение " + QString::number(days) + " дней");
        dialog.accept();
    });
    
    dialog.exec();
}

void MainWindow::on_showMinMaxStayDuration_triggered()
{
    int minDays = INT_MAX;
    int maxDays = 0;
    Room* minRoom = nullptr;
    Room* maxRoom = nullptr;
    
    for (Room& room : myHotel.getRooms()) {
        if (room.getCurrClient()) {
            int stayDays = room.getCurrClient()->checkInDate.daysTo(
                room.getCurrClient()->checkOutDate);
            
            if (stayDays < minDays) {
                minDays = stayDays;
                minRoom = &room;
            }
            if (stayDays > maxDays) {
                maxDays = stayDays;
                maxRoom = &room;
            }
        }
    }
    
    QString message = QString("Минимальная длительность проживания: %1 дней\n"
                            "Максимальная длительность проживания: %2 дней\n\n"
                            "Информация о клиенте с минимальным сроком:\n"
                            "Номер: %3\n"
                            "Клиент: %4\n\n"
                            "Информация о клиенте с максимальным сроком:\n"
                            "Номер: %5\n"
                            "Клиент: %6")
        .arg(minDays)
        .arg(maxDays)
        .arg(minRoom ? minRoom->getNumber() : 0)
        .arg(minRoom && minRoom->getCurrClient() ? minRoom->getCurrClient()->fullName : "Нет данных")
        .arg(maxRoom ? maxRoom->getNumber() : 0)
        .arg(maxRoom && maxRoom->getCurrClient() ? maxRoom->getCurrClient()->fullName : "Нет данных");
    
    QMessageBox::information(this, "Результаты", message);
}

void MainWindow::on_showPreBookedRooms_triggered()
{
    std::vector<Room> preBookedRooms;
    for (const Room& room : myHotel.getRooms()) {
        if (room.getIsReserved()) {
            preBookedRooms.push_back(room);
        }
    }
    
    if (preBookedRooms.empty()) {
        QMessageBox::information(this, "Информация", "Предварительно забронированных номеров не найдено");
        return;
    }
    
    showResultsInNewWindow(preBookedRooms, "Предварительно забронированные номера");
}

void MainWindow::on_showClientsWithExtraPayment_triggered()
{
    std::vector<Room> roomsWithExtraPayment;
    for (const Room& room : myHotel.getRooms()) {
        if (room.getCurrClient() && room.getCurrClient()->extraSum > 0) {
            roomsWithExtraPayment.push_back(room);
        }
    }
    
    if (roomsWithExtraPayment.empty()) {
        QMessageBox::information(this, "Информация", "Клиентов с доплатой не найдено");
        return;
    }
    
    showResultsInNewWindow(roomsWithExtraPayment, "Клиенты с доплатой при выезде");
}

// Добавляю функцию для пересчёта оплаты в строке
void MainWindow::updatePaymentCell(int row) {
    Room& room = myHotel.getRooms()[row];
    Client* client = room.getCurrClient();
    QTableWidgetItem* paymentItem = roomTable->item(row, 5);
    if (!paymentItem) return;
    if (client) {
        int discountAmount = std::max(0, std::min(client->discountAmount, 100));
        QDate in = room.getCheckInDate();
        QDate out = room.getCheckOutDate();
        int days = in.isValid() && out.isValid() ? in.daysTo(out) : 0;
        if (days < 0) days = 0;
        int fullAmount = days * room.getPrice();
        int discountedAmount = fullAmount * (100 - discountAmount) / 100;
        QString paymentText = QString::number(discountedAmount) + " (" + QString::number(fullAmount) + ")";
        paymentItem->setText(paymentText);
    } else {
        paymentItem->setText("—");
    }
}
