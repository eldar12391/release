#include "resultswindow.h"
#include "ui_resultswindow.h"
#include <QDateEdit>
#include <QCheckBox>
#include <QComboBox>

ResultsWindow::ResultsWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::ResultsWindow)
{
    ui->setupUi(this);
    resultsTable = ui->resultsTable;
    setupTable();
}

ResultsWindow::~ResultsWindow()
{
    delete ui;
}

void ResultsWindow::setResults(const std::vector<Room>& rooms)
{
    populateTable(rooms);
}

void ResultsWindow::setTitle(const QString& title)
{
    setWindowTitle(title);
}

void ResultsWindow::setupTable()
{
    resultsTable->setColumnCount(9);
    QStringList headers = {
        "№ в гостинице", "Клиент", "Дата заселения", "Дата выезда",
        "Класс номера", "Оплата", "Скидки", "Бронь", "Доплаты"
    };
    resultsTable->setHorizontalHeaderLabels(headers);
    resultsTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    resultsTable->verticalHeader()->setVisible(false);
}

void ResultsWindow::populateTable(const std::vector<Room>& rooms)
{
    resultsTable->setRowCount(0);
    for (const Room& room : rooms) {
        int row = resultsTable->rowCount();
        resultsTable->insertRow(row);

        // № в гостинице
        resultsTable->setItem(row, 0, new QTableWidgetItem(QString::number(room.getNumber())));

        // Клиент
        Client* client = room.getCurrClient();
        QString clientName = client ? client->fullName : "Нет клиента";
        resultsTable->setItem(row, 1, new QTableWidgetItem(clientName));

        // Дата заселения
        QDateEdit* checkInDateEdit = new QDateEdit(client ? client->checkInDate : QDate::currentDate());
        checkInDateEdit->setCalendarPopup(true);
        checkInDateEdit->setDisplayFormat("dd.MM.yyyy");
        checkInDateEdit->setEnabled(false);
        resultsTable->setCellWidget(row, 2, checkInDateEdit);

        // Дата выезда
        QDateEdit* checkOutDateEdit = new QDateEdit(client ? client->checkOutDate : QDate::currentDate());
        checkOutDateEdit->setCalendarPopup(true);
        checkOutDateEdit->setDisplayFormat("dd.MM.yyyy");
        checkOutDateEdit->setEnabled(false);
        resultsTable->setCellWidget(row, 3, checkOutDateEdit);

        // Класс номера
        QComboBox* typeCombo = new QComboBox();
        typeCombo->addItems({"Standard", "Superior", "Deluxe", "Suite", "Apartment"});
        typeCombo->setCurrentText(room.getTypeToStr());
        typeCombo->setEnabled(false);
        resultsTable->setCellWidget(row, 4, typeCombo);

        // Оплата
        resultsTable->setItem(row, 5, new QTableWidgetItem(QString::number(room.getAmountPaid())));

        // Скидки
        int discountAmount = client ? client->discountAmount : 0;
        resultsTable->setItem(row, 6, new QTableWidgetItem(QString::number(discountAmount)));

        // Бронь
        QCheckBox* checkBox = new QCheckBox();
        checkBox->setChecked(room.getIsReserved());
        checkBox->setEnabled(false);
        resultsTable->setCellWidget(row, 7, checkBox);

        // Доплаты
        int extraSum = client ? client->extraSum : 0;
        resultsTable->setItem(row, 8, new QTableWidgetItem(QString::number(extraSum)));
    }
} 