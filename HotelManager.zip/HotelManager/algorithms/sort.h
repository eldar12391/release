#ifndef SORT_H
#define SORT_H

#include <iostream>
#include <vector>
#include "models/room.h"

enum class SortOrder { Ascending, Descending };

void sortByRoomType(std::vector<Room>& rooms, SortOrder order);
void sortByClientFullName(std::vector<Room>& rooms, SortOrder order);
tm parseDate(const QString& dateStr);
void sortByCheckInDate(std::vector<Room>& rooms, SortOrder order);
void sortByCheckOutDate(std::vector<Room>& rooms, SortOrder order);
void sortByRoomStatus(std::vector<Room>& rooms, SortOrder order);
void sortByRoomNumber(std::vector<Room>& rooms, SortOrder order);
SortOrder getUserSortOrder();
void getUserFieldSort();
void sortField(std::vector<Room>& rooms);

#endif // SORT_H
