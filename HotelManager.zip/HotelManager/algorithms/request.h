#ifndef REQUEST_H
#define REQUEST_H

#include "models/hotel.h"
#include <vector>
#endif // REQUEST_H
